import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {createPowerShellFixtureBatch} from '../goriq/tests/helpers/powershell-fixture-batch.mjs';
const groups=JSON.parse(readFileSync(new URL('./parity-groups.json',import.meta.url)));
const shell=new URL('./pwsh/pwsh',import.meta.url).pathname;
const rows=[];
for(const group of groups){
 const env={...process.env};if(group.stripPSModulePath)delete env.PSModulePath;
 const batch=createPowerShellFixtureBatch({...group,shell,env});
 for(const scenario of group.scenarios){
  const args=['-NoLogo','-NoProfile','-NonInteractive','-File',group.fixture,'-'+group.parameter,scenario];
  for(const[k,v]of Object.entries(group.parameters))args.push('-'+k,v);
  const native=spawnSync(shell,args,{env,encoding:'utf8',timeout:30000,maxBuffer:131072});
  const batched=batch(scenario);
  assert.equal(native.error,undefined);assert.equal(native.status,0,native.stdout+native.stderr);assert.equal(native.stderr,'');
  assert.equal(batched.status,0,batched.stderr);assert.equal(batched.stderr,'');
  const expected=JSON.parse(native.stdout),actual=JSON.parse(batched.stdout);assert.deepEqual(actual,expected);
  const outputSha256=createHash('sha256').update(JSON.stringify(Object.fromEntries(Object.entries(actual).sort(([a],[b])=>a.localeCompare(b))))).digest('hex');
  rows.push({fixture:group.fixture.split('/').at(-1),scenario,outputSha256,status:'MATCH'});
 }
 console.log(JSON.stringify({fixture:group.fixture.split('/').at(-1),cases:group.scenarios.length,status:'MATCH'}));
}
const report={version:1,cases:rows.length,status:'PASS',comparison:'Fresh native PowerShell process versus fresh-runspace batching; complete parsed JSON equality, exit0 and empty stderr',rows};
writeFileSync(new URL('./parity-result.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({cases:rows.length,status:'PASS'}));
