import assert from 'node:assert/strict';
import test from 'node:test';
import { spawnSync, execFileSync } from 'node:child_process';
import { mkdtempSync, writeFileSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

test('fixed prerequisite diagnostics survive without private error text or review authority', () => {
  const base = 'a'.repeat(40), head = 'b'.repeat(40), repository = 'fixture/repository';
  const trusted = execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
  const pr = {number:1,state:'open',head:{sha:head,repo:{full_name:repository}},base:{sha:base,repo:{full_name:repository}}};
  const comparison = {status:'ahead',ahead_by:1,total_commits:1,base_commit:{sha:base},commits:[{sha:head}],files:Array.from({length:31},(_,i)=>({filename:`src/file${i}.ts`,additions:1,deletions:0,patch:'@@ -0,0 +1 @@\n+export const value = 1;'}))};
  for (const mode of ['oversized','private-error']) {
    const temp = mkdtempSync(join(tmpdir(),'goriq-live-probe-'));
    try {
      const preload = join(temp,'fetch.mjs'), report = join(temp,'goriq-ai09-report.json');
      const body = mode === 'private-error' ? 'throw Error("PRIVATE_VALUE_MUST_STAY_PRIVATE");'
        : `if(String(url).includes('/pulls/'))return Response.json(${JSON.stringify(pr)});if(String(url).includes('/compare/'))return Response.json(${JSON.stringify(comparison)});throw Error('INFERENCE_MUST_NOT_RUN');`;
      writeFileSync(preload,`globalThis.fetch = async url => {${body}};\n`);
      const child = spawnSync(process.execPath,['--import',pathToFileURL(preload).href,'scripts/goriq-ai09-ci-review.mjs'],{
        encoding:'utf8',timeout:15000,env:{PATH:process.env.PATH??'',SystemRoot:process.env.SystemRoot??'',
          GORIQ_AI09_REPOSITORY:repository,GORIQ_AI09_PR_NUMBER:'1',GORIQ_AI09_HEAD:head,GORIQ_AI09_BASE:base,
          GORIQ_AI09_TRUSTED_SHA:trusted,GORIQ_AI09_CI_RUN_ID:'1',GORIQ_AI09_CI_CONCLUSION:'success',
          GORIQ_AI09_REPORT_FILE:report,RUNNER_TEMP:temp,GITHUB_TOKEN:'fixture-unprivileged-token'}});
      assert.equal(child.status,0,child.stdout+child.stderr);
      const expected=mode==='oversized'?'invalid_or_oversized_comparison':'review_prerequisite_or_model_unavailable';
      assert.ok(child.stdout.includes('AI09_REVIEW_BLOCKER='+expected),'KNOWN_PREREQUISITE_DIAGNOSTIC_REQUIRED');
      assert.doesNotMatch(child.stdout+child.stderr,/PRIVATE_VALUE_MUST_STAY_PRIVATE|INFERENCE_MUST_NOT_RUN|AI09_INFER_METRIC=/);
      const observed=JSON.parse(readFileSync(report,'utf8'));
      assert.equal(observed.reviewerResult.status,'BLOCKED');
      assert.equal(observed.reviewerResult.mergeAuthorized,false);
      assert.deepEqual(observed.reviewerResult.scope.paths,[]);
    } finally { rmSync(temp,{recursive:true,force:true}); }
  }
});
