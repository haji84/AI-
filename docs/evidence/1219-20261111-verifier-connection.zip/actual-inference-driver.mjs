import {createHash,createPublicKey} from 'node:crypto';
import {execFileSync,spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,mkdirSync,existsSync,readdirSync} from 'node:fs';
import {join} from 'node:path';
import {createTrackedRepairResidentRuntime} from './goriq/src/orchestrator/tracked-repair-resident-runtime.ts';
import {residentDevelopmentGoalDigest} from './goriq/src/orchestrator/resident-development-sequence.ts';
import {goalWorkStateId} from './goriq/src/orchestrator/work-state-integration.ts';
import {JsonFileDevelopmentJobStore} from './goriq/src/orchestrator/development-job-store.ts';
import {JsonFileDevelopmentChangeSetStore} from './goriq/src/orchestrator/development-change-set-store.ts';

const root='/workspace/scratch/760162201692/live-model',runtimeRoot='/workspace/scratch/760162201692/goriq';
const base='374d65e7e2b1d2109ddf97f9cf5c3a1e9716fac1';
const hash=value=>createHash('sha256').update(value).digest('hex');
mkdirSync(root,{recursive:true});
const workspace=join(root,'candidate'),baselineWorkspace=join(root,'baseline');
for(const path of [workspace,baselineWorkspace]) {
  if(!existsSync(path)) execFileSync('git',['worktree','add','--detach',path,base],{cwd:runtimeRoot,stdio:'pipe'});
}
const target='scripts/goriq-ai09-ci-review.mjs',before=readFileSync(join(workspace,target),'utf8');
const slot='  } catch {\n    result = makeBlockedReview(scope, "review_prerequisite_or_model_unavailable");\n  }';
assertUnique(before,slot);
function assertUnique(source,text){if(source.split(text).length!==2)throw Error('LIVE_SLOT_NOT_UNIQUE');}
const probe=readFileSync('/workspace/scratch/760162201692/live-ai09-diagnostic-probe.mjs');
const probeFile=join(root,'frozen-probe.mjs');writeFileSync(probeFile,probe,{flag:'wx'});
const publicKeyFile=join(root,'fixture-public-only.pem');
// Published RFC8032 public vector only. No private signer is created or used.
const publicPem=createPublicKey({key:Buffer.from('302a300506032b6570032100d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a','hex'),format:'der',type:'spki'}).export({type:'spki',format:'pem'}).toString();
writeFileSync(publicKeyFile,publicPem,{flag:'wx'});
const tags=JSON.parse(readFileSync('/workspace/scratch/760162201692/ollama-runtime/tags.json','utf8'));
const model=tags.models.find(m=>m.name==='qwen2.5-coder:3b');if(!model)throw Error('LIVE_MODEL_NOT_INSTALLED');
const goal={title:'Isolated actual-model connection validation for PR1907',description:'Repair the existing AI09 diagnostic omission in an isolated candidate; no original owner Goal mutation and no release.',successCriteria:['A real model-generated candidate preserves known diagnostics and private error boundaries; independent signed acceptance remains required.'],constraints:['Scratch experiment only','No owner credentials or production signer','Preserve rejected and incomplete evidence']};
const objective='Repair the existing catch block so it logs AI09_REVIEW_BLOCKER=<code>. Known Error.message values may be logged only when they exactly match one of: github_read_unavailable, stale_or_foreign_pr, comparison_revision_mismatch, missing_comparison_files, unverifiable_patch_statistics, incomplete_github_patch, invalid_or_oversized_comparison, unsafe_or_unreviewable_patch, duplicate_changed_path, diff_exceeds_local_review_budget, unreviewable_oversized_line, review_source_line_coverage_mismatch, review_chunk_budget_exhausted, review_chunk_coverage_mismatch, pr_changed_during_review. Every other exception must log only review_prerequisite_or_model_unavailable; never expose raw exception text or secrets. Keep makeBlockedReview(scope, "review_prerequisite_or_model_unavailable") unchanged. Keep all review budgets and authority restrictions unchanged.';
const manifest={version:1,profile:'tracked-source-repair-v1',sequence:{version:1,goalDigest:residentDevelopmentGoalDigest(goal),taskScopeId:'issue:1219:isolated-live-model-probe',maxRisk:'low',completionMode:'verified-local-artifact',expiresAt:new Date(Date.now()+3600000).toISOString(),jobs:[{key:'actual-model-diagnostic',objective,criterionIds:['criterion-1'],targetFiles:[target,'tests/live-ai09-diagnostic.test.mjs'],baseRevision:base}]},workspace,baselineWorkspace,targetPath:target,trackedFiles:[{path:target,beforeSha256:hash(before)}],slots:[{id:1,path:target,before:slot}],probe:{file:probeFile,sha256:hash(probe),targetPath:'tests/live-ai09-diagnostic.test.mjs',expectedRedText:'KNOWN_PREREQUISITE_DIAGNOSTIC_REQUIRED'},model:{provider:'ollama',endpoint:'http://127.0.0.1:11435/api/generate',id:model.name,sha256:model.digest.replace(/^sha256:/,''),nPredict:1024,timeoutMs:150000},verifier:{publicKeyFile,publicKeySha256:hash(publicPem),receiptFile:join(root,'UNPROVISIONED-receipt.json')}};
const manifestFile=join(root,'manifest.json'),bytes=JSON.stringify(manifest);writeFileSync(manifestFile,bytes,{flag:'wx'});
const env={GORIQ_TRACKED_REPAIR_MANIFEST_FILE:manifestFile,GORIQ_TRACKED_REPAIR_MANIFEST_SHA256:hash(bytes)};
const compassPath=join(root,'state/compass.sqlite'),goalId=goalWorkStateId(goal),input={goalId,goal,context:[]};
const startedAt=new Date().toISOString();let report,error;
try {report=await createTrackedRepairResidentRuntime({env,runtimeRoot,compassPath,goal}).run(input);}
catch(e){error={name:e.name,message:e.message};}
const jobs=await new JsonFileDevelopmentJobStore(join(root,'state/self-development/jobs.json')).getByGoal(goalId);
const changes=await new JsonFileDevelopmentChangeSetStore(join(root,'state/self-development/change-sets.json')).list();
const probeRun=spawnSync(process.execPath,['--test','tests/live-ai09-diagnostic.test.mjs'],{cwd:workspace,encoding:'utf8',timeout:30000});
writeFileSync(join(root,'candidate-probe.log'),probeRun.stdout+probeRun.stderr,{flag:'wx'});
const diff=execFileSync('git',['diff','--',target],{cwd:workspace,encoding:'utf8'});writeFileSync(join(root,'candidate.patch'),diff,{flag:'wx'});
const journal=join(root,'state/self-development/tracked-repair');
const evidence=existsSync(journal)?readdirSync(journal).sort().map(name=>({name,sha256:hash(readFileSync(join(journal,name)))})):[];
let replay;
if(!error){
 try {const rerun=await createTrackedRepairResidentRuntime({env,runtimeRoot,compassPath,goal,fetchImpl:async()=>{throw Error('LIVE_PREPARED_REPLAY_ATTEMPTED_MODEL_CALL');}}).run(input);replay={report:rerun,noModelCalls:true};}
 catch(e){replay={error:e.message,noModelCalls:false};}
}
const result={schemaVersion:1,scope:'isolated-live-model-source-candidate-only',startedAt,finishedAt:new Date().toISOString(),runtimeBase:base,runtimeSourceSha256:hash(readFileSync(join(runtimeRoot,'src/orchestrator/tracked-repair-resident-runtime.ts'))),originalOwnerGoalTouched:false,originalOwnerGoalAuthenticated:false,fixturePublicKeyOnly:true,independentProductionSigner:false,distributedOwnership:false,model:{name:model.name,digest:model.digest},goalId,jobStates:jobs.map(j=>({jobId:j.jobId,phase:j.phase})),changes:changes.map(c=>({changeSetId:c.changeSetId,status:c.status,sourceRevision:c.candidateRevision,artifactDigest:c.artifactDigest})),report,error,candidateProbe:{exit:probeRun.status,signal:probeRun.signal,sha256:hash(probeRun.stdout+probeRun.stderr)},candidatePatchSha256:hash(diff),candidateSourceSha256:hash(readFileSync(join(workspace,target))),evidence,replay};
writeFileSync(join(root,'result.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({scope:result.scope,error,model:result.model,states:result.jobStates,candidateProbe:result.candidateProbe,replay:replay?.noModelCalls,changed:diff.length>0}));
if(error||probeRun.status!==0)process.exitCode=1;
