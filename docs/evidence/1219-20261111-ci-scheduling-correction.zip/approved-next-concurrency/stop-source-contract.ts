import assert from "node:assert/strict";
import { spawn, type ChildProcess } from "node:child_process";
import { once } from "node:events";
import { setTimeout as delay } from "node:timers/promises";
import { performance } from "node:perf_hooks";
async function original(){
  let child:ChildProcess|undefined;
  const owned=spawn(process.execPath,["-e",'process.on("SIGTERM",()=>{});process.stdout.write("ready");setInterval(()=>{},1000);'],{env:{PATH:process.env.PATH,NODE_DISABLE_COMPILE_CACHE:"1"},stdio:["ignore","pipe","pipe"]});child=owned;
  const stop=async()=>{if(child&&child.exitCode===null&&child.signalCode===null){const done=once(child,"exit");child.kill();await Promise.race([done,delay(3000)]);if(child.exitCode===null)child.kill("SIGKILL");}child=undefined;};
  const signals:Array<{signal:string;atMs:number;accepted:boolean}>=[];
  let started=0;
  const nativeKill=owned.kill.bind(owned);
  owned.kill=(signal)=>{const accepted=nativeKill(signal);signals.push({signal:String(signal??"SIGTERM"),atMs:performance.now()-started,accepted});return accepted;};
  const exited=once(owned,"exit",{signal:AbortSignal.timeout(10000)});
  try{
    await Promise.race([once(owned.stdout!,"data",{signal:AbortSignal.timeout(5000)}),exited.then(()=>{throw Error("FIXTURE_CHILD_EXITED_BEFORE_READY");})]);
    started=performance.now();await stop();const elapsedMs=performance.now()-started;
    const [exitCode,signal]=await exited;
    assert.equal(signal,"SIGKILL");assert.equal(exitCode,null);
    assert.equal(signals[0]?.signal,"SIGTERM");assert.equal(signals[1]?.signal,"SIGKILL");
    assert.equal(signals[1]?.accepted,true);assert.ok(signals[1]!.atMs>=2900&&signals[1]!.atMs<5000);
    process.stdout.write(JSON.stringify({variant:"original",sourceSha256:"04107ea791c22ae5c9d4314f2c86871307ba56416276c16c2111824bd80dd9d5",stopSha256:"631006c3c0bf46cfacbf22ed191ed00b86567052fa539cff20bee3466bf25bdf",elapsedMs,signals,exitCode,signal,childCleared:child===undefined})+"\n");
  }finally{if(owned.exitCode===null&&owned.signalCode===null){nativeKill("SIGKILL");await exited;}}
}

async function cleared(){
  let child:ChildProcess|undefined;
  const owned=spawn(process.execPath,["-e",'process.on("SIGTERM",()=>{});process.stdout.write("ready");setInterval(()=>{},1000);'],{env:{PATH:process.env.PATH,NODE_DISABLE_COMPILE_CACHE:"1"},stdio:["ignore","pipe","pipe"]});child=owned;
  const stop=async()=>{
    if(child&&child.exitCode===null&&child.signalCode===null){
      const done=once(child,"exit");child.kill();
      let timeout:ReturnType<typeof setTimeout>|undefined;
      try{await Promise.race([done,new Promise<void>(resolveStop=>{timeout=setTimeout(resolveStop,3000);})]);}
      finally{clearTimeout(timeout);}
      if(child.exitCode===null)child.kill("SIGKILL");
    }
    child=undefined;
  };
  const signals:Array<{signal:string;atMs:number;accepted:boolean}>=[];
  let started=0;
  const nativeKill=owned.kill.bind(owned);
  owned.kill=(signal)=>{const accepted=nativeKill(signal);signals.push({signal:String(signal??"SIGTERM"),atMs:performance.now()-started,accepted});return accepted;};
  const exited=once(owned,"exit",{signal:AbortSignal.timeout(10000)});
  try{
    await Promise.race([once(owned.stdout!,"data",{signal:AbortSignal.timeout(5000)}),exited.then(()=>{throw Error("FIXTURE_CHILD_EXITED_BEFORE_READY");})]);
    started=performance.now();await stop();const elapsedMs=performance.now()-started;
    const [exitCode,signal]=await exited;
    assert.equal(signal,"SIGKILL");assert.equal(exitCode,null);
    assert.equal(signals[0]?.signal,"SIGTERM");assert.equal(signals[1]?.signal,"SIGKILL");
    assert.equal(signals[1]?.accepted,true);assert.ok(signals[1]!.atMs>=2900&&signals[1]!.atMs<5000);
    process.stdout.write(JSON.stringify({variant:"cleared",sourceSha256:"9fbf8b09ca17d13882617c8fe6dd1db603d256116f47369ff424acaf4eec8018",stopSha256:"b50ae8321bd05db57d2474bfb7ddbcfbb70866ba1547edf57643d1155dab80c4",elapsedMs,signals,exitCode,signal,childCleared:child===undefined})+"\n");
  }finally{if(owned.exitCode===null&&owned.signalCode===null){nativeKill("SIGKILL");await exited;}}
}

await original();
await cleared();
