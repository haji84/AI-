// Scratch diagnosis only. Does not change repository files, test bodies or limits.
// Discovery source: nodejs/node v24.19.0 lib/internal/test_runner/{utils,runner}.js.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { globSync, readFileSync, writeFileSync, openSync, writeSync, closeSync } from 'node:fs';
import { isAbsolute, resolve } from 'node:path';
import { run } from 'node:test';

const [cwdArg, order, scope, outputPrefix, inventoryOnly] = process.argv.slice(2);
assert.ok(cwdArg && isAbsolute(cwdArg), 'absolute repository path required');
assert.ok(outputPrefix && isAbsolute(outputPrefix), 'absolute scratch output prefix required');
assert.ok(['sorted', 'tracked-early', 'tracked-first'].includes(order), 'unknown order');
assert.ok(['all', 'tail'].includes(scope), 'scope must be all or tail');
assert.ok(inventoryOnly === undefined || inventoryOnly === '--inventory-only');
assert.match(process.version, /^v24\./, 'comparison requires Node 24');
assert.equal(process.env.NODE_TEST_CONTEXT, undefined, 'driver must run outside node --test');
assert.ok(![...process.execArgv, process.env.NODE_OPTIONS ?? ''].some(x => x.includes('--no-strip-types')), 'default discovery requires strip-types');
const cwd = resolve(cwdArg);
assert.equal(process.cwd(), cwd, 'launch driver with repository cwd for Node file-wrapper locations');
assert.ok(!resolve(outputPrefix).startsWith(cwd + '/'), 'evidence must be outside repository');
// Exactly the default v24.19.0 pattern when --strip-types is enabled. Same
// basename exclusion callback and default lexical sorting as createTestFileList.
const pattern = '**/{test,test/**/*,test-*,*[._-]test}.{js,mjs,cjs,ts,mts,cts}';
const discovered = globSync(pattern, { cwd, exclude: name => name === 'node_modules' }).sort();
const tracked = 'tests/tracked-repair-runtime.test.ts';
assert.equal(discovered.filter(x => x === tracked).length, 1);
assert.equal(new Set(discovered).size, discovered.length);
// The tail is a representative subset, explicitly not a full-suite claim.
const selected = scope === 'all' ? [...discovered] : discovered.filter(x => x >= 'tests/sequenced-resident-runtime.test.ts');
const sortedIdentity = selected.map(file => ({ file, sha256: createHash('sha256').update(readFileSync(resolve(cwd, file))).digest('hex') }));
let files = [...selected];
if (order === 'tracked-first') files = [tracked, ...files.filter(x => x !== tracked)];
if (order === 'tracked-early') {
  // Mimics only the proposed basename rename, while loading the original path.
  const key = file => file === tracked ? 'tests/autonomous-tracked-repair-runtime.test.ts' : file;
  files.sort((a, b) => key(a) < key(b) ? -1 : key(a) > key(b) ? 1 : 0);
}
assert.deepEqual([...files].sort(), selected);
const identity = createHash('sha256').update(JSON.stringify(sortedIdentity)).digest('hex');
const metadata = { version: 1, proofClass: 'SCRATCH_SCHEDULING_DIAGNOSIS_NOT_CI_RESULT', node: process.version,
  cwd, order, scope, pattern, concurrency: 2, isolation: 'process', discoveredCount: discovered.length,
  selectedCount: files.length, identity, sortedIdentity, files,
  trackedOrdinal: files.indexOf(tracked) + 1, execArgv: process.execArgv,
  cacheEnvPresent: !!process.env.NODE_COMPILE_CACHE, nodeOptionsPresent: !!process.env.NODE_OPTIONS,
  externalTimeoutRequiredMs: 300000 };
writeFileSync(outputPrefix + '.inventory.json', JSON.stringify(metadata, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
if (inventoryOnly) { console.log(JSON.stringify({ inventoryOnly: true, selectedCount: files.length, identity, trackedOrdinal: metadata.trackedOrdinal })); }
else {
  const eventFd = openSync(outputPrefix + '.events.jsonl', 'wx', 0o600);
  const lifecycleFd = openSync(outputPrefix + '.lifecycle.jsonl', 'wx', 0o600);
  const started = process.hrtime.bigint();
  const elapsed = () => Number(process.hrtime.bigint() - started) / 1e6;
  const absoluteFiles = new Map(files.map(file => [resolve(cwd, file), file]));
  const active = new Map(), intervals = [], failures = [], summaries = [];
  const replacer = (_key, value) => value instanceof Error
    ? { name: value.name, message: value.message, stack: value.stack, ...value }
    : typeof value === 'bigint' ? value.toString() : value;
  let maxActive = 0, eventCount = 0;
  try {
    const stream = run({ cwd, files, concurrency: 2, isolation: 'process' });
    for await (const event of stream) {
      const atMs = elapsed(), data = event.data ?? {};
      writeSync(eventFd, JSON.stringify({ atMs, ...event }, replacer) + '\n'); eventCount++;
      if (event.type === 'test:fail') { process.exitCode = 1; failures.push({ atMs, ...data }); }
      if (event.type === 'test:summary') summaries.push(data);
      // Parent file wrappers are named after their exact path. Child test
      // events may also have nesting zero; v24.19 has no entryFile marker.
      const file = typeof data.file === 'string' ? resolve(cwd, data.file) : undefined;
      if (data.nesting === 0 && data.entryFile === undefined && file && absoluteFiles.has(file)
          && (data.name === file || data.name === absoluteFiles.get(file))
          && ['test:enqueue', 'test:dequeue', 'test:complete'].includes(event.type)) {
        if (event.type === 'test:dequeue') { assert.ok(!active.has(file)); active.set(file, atMs); }
        if (event.type === 'test:complete') {
          assert.ok(active.has(file), 'complete without file dequeue: ' + file);
          intervals.push({ file, startedMs: active.get(file), endedMs: atMs, durationMs: atMs - active.get(file), passed: data.details?.passed });
          active.delete(file);
        }
        maxActive = Math.max(maxActive, active.size);
        assert.ok(maxActive <= 2, 'file concurrency exceeded original bound');
        writeSync(lifecycleFd, JSON.stringify({ atMs, type: event.type, file, activeCount: active.size, ...data }, replacer) + '\n');
      }
    }
    assert.equal(active.size, 0, 'unclosed file lifecycle');
    assert.equal(intervals.length, files.length, 'missing file lifecycle events');
    writeFileSync(outputPrefix + '.summary.json', JSON.stringify({ ...metadata, elapsedMs: elapsed(), eventCount, maxActive,
      completedFiles: intervals.length, failures, summaries, intervals }, replacer, 2) + '\n', { flag: 'wx', mode: 0o600 });
    console.log(JSON.stringify({ order, scope, selectedCount: files.length, elapsedMs: elapsed(), failures: failures.length, identity, maxActive }));
  } finally { closeSync(eventFd); closeSync(lifecycleFd); }
}
