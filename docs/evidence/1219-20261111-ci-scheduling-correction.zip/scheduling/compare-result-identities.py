from pathlib import Path
from collections import Counter
import json,hashlib
ROOT=Path(__file__).resolve().parent
FIELDS=['name','nesting','line','column']
def canonical(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def relative(value,cwd):
 if not isinstance(value,str):return value
 try:return str(Path(value).relative_to(cwd))
 except ValueError:return value
reports=[];identities=[]
for prefix in ['original-full','early-full']:
 meta=json.loads((ROOT/(prefix+'.inventory.json')).read_text());cwd=Path(meta['cwd']);buckets={k:[]for k in ['passed','failed','skipped','todo']}
 raw=(ROOT/(prefix+'.events.jsonl')).read_bytes()
 for line in raw.splitlines():
  e=json.loads(line);d=e.get('data',{})
  if e['type']not in ['test:pass','test:fail'] or d.get('details',{}).get('type')!='test':continue
  value={key:d.get(key)for key in FIELDS}
  value.update(file=relative(d.get('file'),cwd),entryFile=relative(d.get('entryFile')or d.get('file'),cwd))
  status='skipped'if d.get('skip')else 'todo'if d.get('todo')else 'passed'if e['type']=='test:pass'else'failed'
  if d.get('skip'):value['skip']=d['skip']
  if d.get('todo'):value['todo']=d['todo']
  if status=='failed':
   error=d.get('details',{}).get('error',{});value['error']={k:error.get(k)for k in ['message','code','failureType']}
  buckets[status].append(value)
 for values in buckets.values():values.sort(key=canonical)
 counts={k:len(v)for k,v in buckets.items()};stats=json.loads((ROOT/(prefix+'.derived-stats.json')).read_text());g=stats['globalSummaries'][-1]['counts']
 assert sum(counts.values())==g['tests']
 assert all(counts[k]==g[k]for k in counts)
 hashes={k:hashlib.sha256(canonical(v).encode()).hexdigest()for k,v in buckets.items()}
 report={'prefix':prefix,'rawEventsSha256':hashlib.sha256(raw).hexdigest(),'counts':counts,'caseIdentitySha256':hashes,'globalCountsMatch':True,'failedIdentities':buckets['failed']}
 reports.append(report);identities.append(buckets)
 (ROOT/(prefix+'.derived-result-identities.json')).write_text(json.dumps(buckets,indent=2)+'\n')
comparison={'runs':reports,'sameIdentityAndMultiplicity':{k:identities[0][k]==identities[1][k]for k in identities[0]},'sameAllTestResults':identities[0]==identities[1]}
(ROOT/'result-identity-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n');print(json.dumps(comparison,indent=2))
