"""Read raw Node test events; never edit the running driver, evidence or repository."""
from pathlib import Path
from collections import Counter
import hashlib,json,sys

ROOT=Path(__file__).resolve().parent

def digest(data):return hashlib.sha256(data).hexdigest()
def relative(value,cwd):
 if not isinstance(value,str):return value
 p=Path(value)
 try:return str(p.relative_to(cwd)) if p.is_absolute() else str(p)
 except ValueError:return str(p)

def analyze(prefix):
 inventory_path=ROOT/(prefix+'.inventory.json');event_path=ROOT/(prefix+'.events.jsonl')
 if not inventory_path.exists() or not event_path.exists():return None
 inventory_bytes=inventory_path.read_bytes();meta=json.loads(inventory_bytes);cwd=Path(meta['cwd']);files=meta['files'];file_set=set(files)
 source=event_path.read_bytes();lines=source.splitlines(keepends=True);events=[];incomplete_bytes=0
 for i,line in enumerate(lines):
  try:events.append(json.loads(line))
  except json.JSONDecodeError:
   if i==len(lines)-1 and not line.endswith(b'\n'):incomplete_bytes=len(line)
   else:raise
 expected_identity=digest(json.dumps(meta['sortedIdentity'],ensure_ascii=False,separators=(',',':')).encode())
 assert expected_identity==meta['identity'],'inventory identity mismatch'
 assert len(files)==len(file_set)==meta['selectedCount']==669,'669 unique files required'
 assert set(x['file']for x in meta['sortedIdentity'])==file_set
 active={};enqueued={};dequeued={};completed={};intervals=[];segments=[];failures=[];skips=[];todos=[];case_completions=[];summaries=[];anomalies=[];max_active=0;previous=None
 root_events=[]
 def case_identity(data):
  return {'entryFile':relative(data.get('entryFile') or data.get('file'),cwd),'file':relative(data.get('file'),cwd),'line':data.get('line'),'column':data.get('column'),'nesting':data.get('nesting'),'name':data.get('name'),'type':data.get('details',{}).get('type',data.get('type'))}
 for event in events:
  kind=event['type'];at=event['atMs'];data=event.get('data',{});file=relative(data.get('file'),cwd)
  is_root=(data.get('nesting')==0 and data.get('entryFile') is None and file in file_set and data.get('name') in (file,str(cwd/file)))
  if kind=='test:summary':summaries.append({'atMs':at,**data})
  if kind=='test:complete' and not is_root:
   item={**case_identity(data),'atMs':at,'passed':data.get('details',{}).get('passed'),'durationMs':data.get('details',{}).get('duration_ms')}
   case_completions.append(item)
   if data.get('skip'):skips.append({**case_identity(data),'skip':data['skip']})
   if data.get('todo'):todos.append({**case_identity(data),'todo':data['todo']})
   if data.get('details',{}).get('passed') is False:failures.append({**item,'details':data.get('details')})
  if not is_root or kind not in ('test:enqueue','test:dequeue','test:complete'):continue
  root_events.append({'type':kind,'atMs':at,'file':file,'testId':data.get('testId'),'passed':data.get('details',{}).get('passed')})
  if kind=='test:enqueue':
   if file in enqueued:anomalies.append('duplicate enqueue: '+file)
   enqueued[file]=at;continue
  if previous is not None and at>=previous:
   segments.append({'fromMs':previous,'toMs':at,'durationMs':at-previous,'activeCount':len(active),'files':sorted(active)})
  if kind=='test:dequeue':
   if file in active or file in dequeued:anomalies.append('duplicate dequeue: '+file)
   active[file]=at;dequeued[file]=at
  else:
   if file not in active:anomalies.append('complete without dequeue: '+file)
   else:
    start=active.pop(file);row={'file':file,'dequeuedAtMs':start,'completedAtMs':at,'intervalMs':at-start,'reportedDurationMs':data.get('details',{}).get('duration_ms'),'passed':data.get('details',{}).get('passed')}
    intervals.append(row);completed[file]=row
  previous=at;max_active=max(max_active,len(active))
 last_at=events[-1]['atMs']if events else None
 if active and previous is not None and last_at>previous:segments.append({'fromMs':previous,'toMs':last_at,'durationMs':last_at-previous,'activeCount':len(active),'files':sorted(active),'observationOnly':True})
 if max_active>2:anomalies.append('file concurrency exceeded 2')
 full=(len(completed)==len(files) and not active and not anomalies and not incomplete_bytes)
 global_summaries=[s for s in summaries if not s.get('file') and not s.get('entryFile')]
 tail=None
 if segments:
  final=[s for s in segments if s['durationMs']>0]
  if final and final[-1]['activeCount']==1:
   end=final[-1]['toMs'];start=final[-1]['fromMs'];last_files=final[-1]['files']
   for seg in reversed(final[:-1]):
    if seg['activeCount']==1 and seg['files']==last_files and seg['toMs']==start:start=seg['fromMs']
    else:break
   tail={'fromMs':start,'toMs':end,'durationMs':end-start,'file':last_files[0],'completeRun':full}
 tracked='tests/tracked-repair-runtime.test.ts'
 file_summaries=[s for s in summaries if s.get('entryFile') or s.get('file')]
 observation={'prefix':prefix,'proofClass':'DERIVED_SCRATCH_SCHEDULING_STATISTICS_NOT_CI','inventoryIdentity':meta['identity'],'inventorySha256':digest(inventory_bytes),'rawEventsSha256':digest(source),'snapshotBytes':len(source),'trailingIncompleteBytes':incomplete_bytes,'eventCount':len(events),'lastObservedAtMs':last_at,'allFileLifecyclesCompleted':full,'order':meta['order'],'node':meta['node'],'files':len(files),'enqueuedFiles':len(enqueued),'dequeuedFiles':len(dequeued),'completedFiles':len(completed),'maxActiveFiles':max_active,'unstartedFiles':[f for f in files if f not in dequeued],'activeFilesAtObservation':[{'file':f,'dequeuedAtMs':t}for f,t in active.items()],'rootFileFailures':[row for row in intervals if row['passed'] is False],'caseFailures':failures,'skipIdentities':sorted(skips,key=lambda x:json.dumps(x,sort_keys=True)),'todoIdentities':sorted(todos,key=lambda x:json.dumps(x,sort_keys=True)),'observedCaseCompletions':len(case_completions),'observedCaseTypeCounts':dict(Counter(x['type']for x in case_completions)),'globalSummaries':global_summaries,'completedFileSummaryCount':len(file_summaries),'firstFileDequeueAtMs':min(dequeued.values())if dequeued else None,'lastFileCompleteAtMs':max((x['completedAtMs']for x in intervals),default=None),'timeByActiveFileCountMs':{str(n):sum(s['durationMs']for s in segments if s['activeCount']==n)for n in (0,1,2)},'finalSingleFileTail':tail,'tracked':{'ordinal':meta['trackedOrdinal'],'dequeuedAtMs':dequeued.get(tracked),'complete':completed.get(tracked),'summary':next((s for s in file_summaries if relative(s.get('entryFile') or s.get('file'),cwd)==tracked),None)},'intervals':sorted(intervals,key=lambda x:x['dequeuedAtMs']),'lastLifecycleEvents':root_events[-12:],'anomalies':anomalies,'limitations':['Times are raw event receipt times in one diagnostic driver, not OS process CPU or Docker timings.','Partial files remain partial; no missing test or incomplete run is counted as passed.','Root lifecycle events are identified from outer event.type and exact inventory file names; data.type is not used as event type.']}
 dest=ROOT/(prefix+('.derived-stats.json'if full else '.derived-stats.partial.json'));dest.write_text(json.dumps(observation,indent=2)+'\n')
 (ROOT/(prefix+'.derived-root-lifecycle.jsonl')).write_text(''.join(json.dumps(x,separators=(',',':'))+'\n'for x in root_events))
 (ROOT/(prefix+'.derived-active-segments.json')).write_text(json.dumps(segments,indent=2)+'\n')
 return observation,meta

def brief(x):
 return {k:x[k]for k in ['prefix','order','eventCount','lastObservedAtMs','allFileLifecyclesCompleted','files','completedFiles','maxActiveFiles','activeFilesAtObservation','observedCaseCompletions','observedCaseTypeCounts','globalSummaries','timeByActiveFileCountMs','finalSingleFileTail','tracked','anomalies']}|{'caseFailureCount':len(x['caseFailures']),'rootFailureCount':len(x['rootFileFailures']),'skipCount':len(x['skipIdentities'])}

if __name__=='__main__':
 names=sys.argv[1:]or['original-full','early-full'];runs={}
 for name in names:
  result=analyze(name)
  if result:runs[name]=result;print(json.dumps(brief(result[0]),indent=2))
 if len(runs)==2:
  (an,(a,am)),(bn,(b,bm))=list(runs.items())
  same_sources=am['sortedIdentity']==bm['sortedIdentity'];same_inventory=set(am['files'])==set(bm['files'])
  compared={'runs':[an,bn],'sameAll669SourcesAndHashes':same_sources,'sameAll669FileInventory':same_inventory,'sameInventoryIdentity':am['identity']==bm['identity'],'onlyOrderVaries':same_sources and same_inventory and am['files']!=bm['files'],'bothFileLifecyclesComplete':a['allFileLifecyclesCompleted']and b['allFileLifecyclesCompleted'],'globalCounts':[x['globalSummaries'][-1].get('counts')if x['globalSummaries']else None for x in (a,b)],'sameSkipIdentity':a['skipIdentities']==b['skipIdentities'],'skipCounts':[len(x['skipIdentities'])for x in (a,b)],'failures':[{'rootFileFailures':x['rootFileFailures'],'caseFailures':x['caseFailures']}for x in (a,b)],'tracked':[x['tracked']for x in (a,b)],'finalSingleFileTail':[x['finalSingleFileTail']for x in (a,b)],'lastFileCompleteAtMs':[x['lastFileCompleteAtMs']for x in (a,b)],'lastObservedAtMs':[x['lastObservedAtMs']for x in (a,b)],'completedFiles':[x['completedFiles']for x in (a,b)],'anomalies':[x['anomalies']for x in (a,b)]}
  (ROOT/'scheduling-derived-comparison.json').write_text(json.dumps(compared,indent=2)+'\n');print(json.dumps(compared,indent=2))
