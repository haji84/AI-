import { run } from 'node:test';
const files = ['tests/trusted-device-auth-contract.test.mjs', 'tests/task-authorization.test.ts'];
for await (const event of run({files,concurrency:2,isolation:'process'})) {
  const d=event.data;
  if (['test:dequeue','test:complete'].includes(event.type) && d.nesting===0 && d.entryFile===undefined && files.some(f=>d.name===f || d.name?.endsWith('/'+f))) console.log(JSON.stringify({type:event.type,name:d.name,file:d.file,nesting:d.nesting,entryFile:d.entryFile}));
  if(event.type==='test:fail')process.exitCode=1;
}
