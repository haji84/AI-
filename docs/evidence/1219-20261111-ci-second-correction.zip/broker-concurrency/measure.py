import os, sys, json, time, resource, subprocess, signal
from pathlib import Path

out=Path(__file__).resolve().parent
variant=sys.argv[1]
assert variant in ('sequential','parallel','actual')
cpus=sorted(os.sched_getaffinity(0))[:2]
assert len(cpus)==2
os.sched_setaffinity(0,cpus)
env=dict(os.environ)
env.update(POWERSHELL_TELEMETRY_OPTOUT='1',POWERSHELL_UPDATECHECK='Off',DOTNET_CLI_TELEMETRY_OPTOUT='1',NEXT_TELEMETRY_DISABLED='1')
env['PATH']='/workspace/scratch/760162201692/ci-investigation/pwsh:'+env['PATH']
root=Path('/workspace/scratch/760162201692/goriq')
usage0=resource.getrusage(resource.RUSAGE_CHILDREN)
start=time.monotonic()
max_rss=0;max_processes=0;max_threads=0;samples=0;timed_out=False
with (out/(variant+'.log')).open('w') as log:
 p=subprocess.Popen(['node','--test',str(root/'tests/resident-sequence-broker-e2e.test.ts' if variant=='actual' else out/(variant+'.test.ts'))],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  if time.monotonic()-start>=300:
   timed_out=True;os.killpg(p.pid,signal.SIGKILL);break
  entries={}
  for path in Path('/proc').iterdir():
   if not path.name.isdigit():continue
   try:
    fields={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in (path/'status').read_text().splitlines() if ':' in line}
    entries[int(path.name)]={'parent':int(fields.get('PPid','0')),'rss':int(fields.get('VmRSS','0 kB').split()[0])*1024,'threads':int(fields.get('Threads','0'))}
   except (OSError,ValueError):pass
  seen=set();todo=[p.pid];rss=0;threads=0
  while todo:
   pid=todo.pop()
   if pid in seen or pid not in entries:continue
   seen.add(pid);entry=entries[pid];rss+=entry['rss'];threads+=entry['threads']
   todo.extend(child for child,info in entries.items() if info['parent']==pid)
  samples+=1;max_rss=max(max_rss,rss);max_processes=max(max_processes,len(seen));max_threads=max(max_threads,threads)
  time.sleep(.1)
 code=p.wait()
elapsed=time.monotonic()-start
usage1=resource.getrusage(resource.RUSAGE_CHILDREN)
record={'variant':variant,'exitCode':code,'outerTimeoutMs':300000,'timedOut':timed_out,'wallSeconds':elapsed,'userCpuSeconds':usage1.ru_utime-usage0.ru_utime,'systemCpuSeconds':usage1.ru_stime-usage0.ru_stime,'affinity':cpus,'sampleIntervalSeconds':.1,'samples':samples,'sampledPeakDescendantRssBytes':max_rss,'sampledPeakProcesses':max_processes,'sampledPeakThreads':max_threads,'maxChildRssKiB':usage1.ru_maxrss,'scope':'Only this test file with all descendant processes. Sampled RSS sums may double-count shared pages. No Docker memory/PID/cgroup quota equivalence.'}
(out/(variant+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record));sys.exit(code)
